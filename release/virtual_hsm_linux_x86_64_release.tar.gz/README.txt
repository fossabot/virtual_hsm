Virtual HSM Linux Build
------------------------

This package contains the Virtual HSM executable built as a static binary.
No additional runtime dependencies are required.
