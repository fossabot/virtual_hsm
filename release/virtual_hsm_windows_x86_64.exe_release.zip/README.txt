Virtual HSM Windows Build
------------------------

This package contains the Virtual HSM executable built as a static binary.
No additional DLLs are required to run this application.
